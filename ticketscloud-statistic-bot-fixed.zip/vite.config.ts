import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import express from 'express';
import 'dotenv/config';
import { defineConfig } from 'vite';
import { apiRouter } from './src/server/routes.js';
import { botEngine } from './src/server/botEngine.js';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'telegram-bot-api-plugin',
        configureServer(server) {
          // Запускаем бота при старте Vite в режиме разработки
          botEngine.startEngine();

          // Подключаем Express API к дев-серверу Vite
          const app = express();
          app.use(express.json());
          app.use('/api', apiRouter);

          server.middlewares.use(app);
        }
      }
    ],
    resolve: {
      alias: {
        // Настраиваем алиас @ на папку src для совпадения с tsconfig.json
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

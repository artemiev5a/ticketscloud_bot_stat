import assert from 'node:assert/strict';
import test from 'node:test';
import { ticketscloudService } from '../src/server/ticketscloudService.ts';

test('uses the documented v2 endpoint, key authentication, UTC boundaries and every page', async () => {
  const requests: URL[] = [];
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(input.toString());
    requests.push(url);
    assert.equal(init?.headers && new Headers(init.headers).get('Authorization'), 'key organizer-key');
    const page = url.searchParams.get('page');
    const body = page === '1'
      ? {
          data: [{ event: 'event-a', tickets: [{ full: '110.00' }], values: { full: '110.00' } }],
          pagination: { page: 1, page_size: 200, total: 201 },
          refs: { events: { 'event-a': { title: { text: 'Первое' } } } }
        }
      : {
          data: [{ event: 'event-b', tickets: [{ full: '90.00' }, { full: '90.00' }], values: { full: '180.00' } }],
          pagination: { page: 2, page_size: 200, total: 201 },
          refs: { events: { 'event-b': { title: { text: 'Второе' } } } }
        };
    return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }) as typeof fetch;

  try {
    const result = await ticketscloudService.getStats(' organizer-key ', {
      from: new Date('2026-08-10T00:00:00.000Z'),
      to: new Date('2026-08-11T00:00:00.000Z')
    });
    assert.equal(requests.length, 2);
    assert.equal(requests[0].origin, 'https://ticketscloud.com');
    assert.equal(requests[0].pathname, '/v2/resources/orders');
    assert.equal(requests[0].searchParams.get('status'), 'done');
    assert.equal(requests[0].searchParams.get('created_at'), '2026-08-10T00:00:00.000Z,2026-08-11T00:00:00.000Z');
    assert.match(result.text, /Проданных билетов: <b>3<\/b>/);
    assert.match(result.text, /290,00 ₽/);
    assert.match(result.text, /Первое/);
    assert.match(result.text, /Второе/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('does not make a request when the user has not provided a key', async () => {
  const result = await ticketscloudService.getStats('');
  assert.match(result.text, /API-ключ не указан/);
});
